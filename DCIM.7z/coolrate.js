const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
let rating = Math.floor(Math.random() * 100);
let rated =
  context.params.event.author.username +
  '#' +
  context.params.event.author.discriminator;
if (context.params.event.mentions.length > 0) {
  rated =
    context.params.event.mentions[0].username +
    '#' +
    context.params.event.mentions[0].discriminator;
}
let message = null;
if (rating === 100) {
  message = `You're the coolest person ever! Praise be **${rated.slice(
    0,
    -5
  )}**!`;
}
if (rating >= 75 && rating !== 100) {
  message = "You're pretty cool.";
}
if (rating < 75 && rating > 50) {
  message = 'You\re above average in terms of coolness.';
}
if (rating === 50) {
  message = "You're the most normal person I know.";
}
if (rating < 50 && rating >= 25) {
  message = 'You\re ok.';
}
if (rating < 25 && rating !== 0) {
  message = "You're pretty boring.";
}
if (rating === 0) {
  message = "You're the most boring person ever.";
}

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

if (context.params.event.content.startsWith(`${commandPrefix}coolrate`)) {
  await lib.discord.channels['@0.1.2'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: `**${rated}** is ${rating}% cool. ${message}`,
  });
}
