# Advance warn command
this counts how many warns the user have i just added ban,unban and kick cause why not this is warn command UwU

### How to Install?
To install this app successfully. just follow the below steps.

- Install the app from above **Install** button
- The app installer will ask for prefix, fill that up
- This is it 🥳 !!

## Warn
![](https://cdn.discordapp.com/attachments/893767084239093770/899451452437712896/unknown.png)

## Log channel
![](https://cdn.discordapp.com/attachments/893767084239093770/899451675968937984/unknown.png)

## Copy this
https://docs.google.com/spreadsheets/d/1Z--vovPEaeW82lsZosIFiI4ZlI3Z3tv7bbJkl_og34A/edit?usp=sharing

## Author
- 💪 App Author: `Kaedehara Kazuha#9299 and with the help of Kangabru#0816` 

### Words from Author
- This is my second app with **Autocode** and i really enjoyed using **Autocode**, it is really a great website to use create **bots**