const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
let activitynameslist = [
  'my owner yt video',
  `over the server im in`,
  'the people using my commands perfectly :sunglasses: ',
];
let ActivityChoice = Math.floor(Math.random() * activitynameslist.length);
let activity = activitynameslist[ActivityChoice];

// Do not add any more status as then this snippet will not work just Change them and enjoy
let activitytypelist = [`WATCHING`];
let ActypeChoice = Math.floor(Math.random() * activitytypelist.length);
let activitytype = activitytypelist[ActypeChoice];

//Starting of status
let status = [`ONLINE`, `DND`, `IDLE`];
let statusChoice = Math.floor(Math.random() * status.length);
let statustype = status[statusChoice];

let result = await lib.discord.users['@0.1.1'].me.status.update({
  activity_name: `${activity}`,
  activity_type: `${activitytype}`,
  status: `${statustype}`,
});
