//Created By Ders#0001
 //Feel Free To DM Me With Any Questions

const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

//Sets Your Bots ID For The Invite
let info = await lib.discord.users['@0.1.4'].me.list();
let id = info.id;

//Feel Free To Customize The Embed To Whatever You Want
await lib.discord.channels['@0.2.0'].messages.create({
  channel_id: `${context.params.event.system_channel_id}`,
  content: '',
  tts: false,
  components: [
    {
      type: 1,
      components: [
        {
          style: 5,
          label: `Invite Me To Your Server`,
          url: `https://discord.com/oauth2/authorize?client_id=${id}&scope=identify%20bot%20applications.commands&permissions=2146958591`,
          disabled: false,
          type: 2,
        },
      ],
    },
  ],
  embeds: [
    {
      type: 'rich',
      title: `👋〡Thank You For Adding Me To Your Server! `,
      description: `Thank You So Much For Adding Me To Your Server! I Am Super Happy To Be Here!\n\n🔗〡If You Would Like To Add Me To Another Server, Please Click The Link Below`,
      color: 0x00ffff,
    },
  ],
});
