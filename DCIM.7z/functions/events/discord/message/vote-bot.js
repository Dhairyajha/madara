const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

let message = context.params.event.content;

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({ key: 'prefix', defaultValue: {} });
  return prefixMap[context.params.event.guild_id] || '!'
}

const commandPrefix = await getGuildPrefix();
if (message.startsWith(`${commandPrefix}vote bot`)) {
await lib.discord.channels['@0.2.0'].messages.create({
  "channel_id": `${context.params.event.channel_id}`,
  "content": "",
  "tts": false,
  "components": [
    {
      "type": 1,
      "components": [
        {
          "style": 5,
          "label": `vote the bot`,
          "url": `https://top.gg/bot/894948538222518364/vote`,
          "disabled": false,
          "type": 2
        }
      ]
    }
  ],
  "embeds": [
    {
      "type": "rich",
      "title": `bot Vote`,
      "description": `Click the button to vote for me!`,
      "color": 0x00FFFF
    }
  ]
});
}
