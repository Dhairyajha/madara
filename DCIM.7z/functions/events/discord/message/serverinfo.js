const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

if (context.params.event.content.startsWith(`${commandPrefix}serverinfo`)) {
  let guild = await lib.discord.guilds['@0.1.0'].retrieve({
    guild_id: `${context.params.event.guild_id}`,
    with_counts: true,
  });
  let member = guild.approximate_member_count;
  let guildUrl = guild.icon_url;
  let gifCheckResponse = await lib.http.request['@1.1.5']({
    method: 'GET',
    url: guild.icon_url.replace('.png', '.gif'),
  });
  if (gifCheckResponse.statusCode === 200) {
    guildUrl = guild.icon_url.replace('.png', '.gif');
  }
  let channel = await lib.discord.guilds['@0.1.0'].channels.list({
    guild_id: `${context.params.event.guild_id}`,
  });
  let bans = await lib.discord.guilds['@0.1.0'].bans.list({
    guild_id: `${context.params.event.guild_id}`,
  });
  const owner = await lib.discord.guilds['@0.1.0'].members.retrieve({
    user_id: guild.owner_id, // required
    guild_id: guild.id, // required
  });
  let members;
  try {
    members = await lib.discord.guilds['@0.0.6'].members.list({
      guild_id: `${context.params.event.guild_id}`,
      limit: 1000,
    });
  } catch (e) {
    console.log(e);
  }
  const category = channel.filter((x) => !x.parent_id);
  const text = channel.filter((x) => x.type == 0);
  const voice = channel.filter((x) => x.type == 2);
  const bot = members && members.filter((x) => x.user.bot);

  await lib.discord.channels['@0.1.1'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: '',
    tts: false,
    embed: {
      type: 'rich',
      title: '',
      description: '',
      color: 0x00ffff,
      fields: [
        {
          name: 'Owner',
          value: `${owner.user.username}`,
        },
        {
          name: 'Members',
          value: `${member}`,
          inline: true,
        },
        {
          name: 'Bots',
          value: `${
            bot ? bot.length : 'Enable privileged intents to see this'
          }`,
          inline: true,
        },
        {
          name: 'Categories',
          value: `${category.length}`,
        },
        {
          name: 'Text Channels',
          value: `${text.length}`,
          inline: true,
        },
        {
          name: 'Voice Channels',
          value: `${voice.length}`,
          inline: true,
        },
        {
          name: 'Roles',
          value: `${guild.roles.length}`,
        },
        {
          name: 'Emojis',
          value: `${guild.emojis.length}`,
        },
        {
          name: 'Ban Count',
          value: `${bans.length}`,
        },
      ],
      thumbnail: {
        url: `${guildUrl}`,
        height: 0,
        width: 0,
      },
      author: {
        name: `${guild.name}`,
      },
    },
  });
}
