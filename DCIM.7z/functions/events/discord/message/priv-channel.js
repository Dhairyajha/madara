  const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();
if (context.params.event.content.startsWith(`${commandPrefix}priv-chnl`)) {
await lib.discord.channels['@0.1.1'].permissions.update({
  overwrite_id: `${context.params.event.guild_id}`,
  channel_id: `${context.params.event.channel_id}`,
  deny: `${1 << 10}`,
  type: 0
});
await lib.discord.channels['@0.2.1'].messages.create({
  channel_id: `${context.params.event.channel_id}`,
  content: `✅ | Succesfully made this channel a private channel!`
});
}

if (context.params.event.content.startsWith(`${commandPrefix}unpriv-chnl`)) {
  await lib.discord.channels['@0.2.1'].permissions.update({
    overwrite_id: `${context.params.event.guild_id}`,
    channel_id: `${context.params.event.channel_id}`,
    allow: `${1 << 10}`,
    type: 0
  });
await lib.discord.channels['@0.2.1'].messages.create({
  channel_id: `${context.params.event.channel_id}`,
  content: `✅ | succesfully made this channel a public!`
});
}