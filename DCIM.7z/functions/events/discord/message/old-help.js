const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();
if (context.params.event.content.startsWith(`jhbawjkgbabagkbaghbwaghbeahgbean`)) {
  await lib.discord.channels['@0.1.2'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: ``,
    tts: false,
    embeds: [
      {
        type: 'rich',
        title: `Help command`,
        description: ``,
        color: 0x00f7ff,
        fields: [
          {
            name: `\`prefix\``,
            value: `(${commandPrefix})`,
          },
          {
            name: `\`Moderation\``,
            value: `userwarns, kick, ban, unban, mute, unmute, purge, lock, unlock, tempmute, tempban, poll, member-autorole, change-prefix, poll-ping <role> `,
          },
          {
            name: `\`Music\``,
            value: `setup <channel>`,
          },
          {
            name: `\`general\``,
            value: `my warns, vote bot, vote server crmwy, afk, invite, ytchannel, myperms, report, botinfo, whois`,
          },
          {
            name: `\`welcome message\``,
            value: `setchannel <#channel>, setmsg (if u want to mention a user say <@{{member_id}}>), setbg choose/random/url, blur, preview,`,
          },
          {
            name: `\`fun\``,
            value: `ttt <@user>, hack <@user>, joke`,
          },
          {
            name: `\`economy\``,
            value: `bal/balance`,
          },
        ],
      },
    ],
  });
}
console.log(commandPrefix);
