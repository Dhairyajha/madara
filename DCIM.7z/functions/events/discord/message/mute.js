const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

module.exports = async (event, context) => {
  // Use this function to get the prefix in other files.
  // Use like `const prefix = await getGuildPrefix();`
  const getGuildPrefix = async () => {
    const prefixMap = await lib.utils.kv['@0.1.16'].get({
      key: 'prefix',
      defaultValue: {},
    });
    return prefixMap[context.params.event.guild_id] || '!';
  };

  const commandPrefix = await getGuildPrefix();

  let sleep = async (ms) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve();
      }, ms || 0);
    });
  };

  if (context.params.event.content.startsWith(`${commandPrefix}mute`)) {
    console.log(commandPrefix);
    let text = event.content.split(` `);
    let reason = text.slice(2).join(' ');
    let roles = await lib.discord.guilds['@0.1.0'].roles.list({
      guild_id: event.guild_id,
    });
    let mutedRole = roles.find((role) => {
      return role.name.toLowerCase().startsWith('muted');
    });
    let canMute = false;
    let authorRoles = roles.filter((role) => {
      return event.member.roles.indexOf(role.id) > -1;
    });
    for (let i = 0; i < authorRoles.length; i++) {
      let role = authorRoles[i];
      canMute =
        role.name.toLowerCase().match(/\bmod/i) ||
        role.name.toLowerCase().match(/\badmin/i) ||
        role.permission_names.includes('ADMINISTRATOR');
      if (canMute) {
        break;
      }
    }
    if (!text[1]) {
      await lib.discord.channels['@0.0.6'].messages.create({
        channel_id: event.channel_id,
        content: '',
      });
    } else if (!canMute) {
      await lib.discord.channels['@0.0.6'].messages.create({
        channel_id: event.channel_id,
        content: `You dont have the permission`,
      });
    } else if (!text[1].startsWith(`<@!`)) {
      await lib.discord.channels['@0.0.6'].messages.create({
        channel_id: event.channel_id,
        content: `Tag not found`,
      });
    } else {
      let anotherUser = await lib.discord.guilds['@0.0.6'].members.retrieve({
        user_id: event.mentions[0].id,
        guild_id: event.guild_id,
      });
      let cannotBeMuted = false;
      let mentionedUserRoles = roles.filter((role) => {
        return anotherUser.roles.indexOf(role.id) > -1;
      });
      for (let i = 0; i < mentionedUserRoles.length; i++) {
        let anotherRole = mentionedUserRoles[i];
        cannotBeMuted =
          anotherRole.name.toLowerCase().match(/\bmod/i) ||
          anotherRole.name.toLowerCase().match(/\badmin/i) ||
          anotherRole.permission_names.includes('ADMINISTRATOR');
        if (cannotBeMuted) {
          await lib.discord.channels['@0.0.6'].messages.create({
            channel_id: event.channel_id,
            content: `Sorry, the person you're trying to mute is an admin/mod`,
          });
          return;
        }
      }
      if (!mutedRole) {
        await lib.discord.channels['@0.0.6'].messages.create({
          channel_id: event.channel_id,
          content: 'Mute role not found',
        });
      } else {
        let mentionedUserMutedRole = mentionedUserRoles.find((role) => {
          return role.name.toLowerCase().startsWith('mute');
        });
        if (!!mentionedUserMutedRole) {
          await lib.discord.channels['@0.0.6'].messages.create({
            channel_id: event.channel_id,
            content: 'This user is already muted',
          });
        } else {
          let anotherUser = await lib.discord.guilds['@0.0.6'].members.retrieve(
            {
              user_id: event.mentions[0].id,
              guild_id: event.guild_id,
            }
          );
          console.log(anotherUser.roles);
          let userOldRoles = await lib.utils.kv['@0.1.16'].set({
            key: `userId_${event.mentions[0].id}_${event.guild_id}`,
            value: anotherUser.roles,
          });
          await lib.discord.channels['@0.0.6'].messages.create({
            channel_id: event.channel_id,
            content: ` `,
            embed: {
              title: ` `,
              type: 'rich',
              color: 0xabccff,
              description: `${text[1]} is muted: ${reason} `,
            },
          });
           await lib.discord.guilds['@0.1.0'].members.roles.update({
            role_id: mutedRole.id,
            user_id: event.mentions[0].id,
            guild_id: event.guild_id,
          });
          for (let i = 0; i < anotherUser.roles.length; i++) {
            await sleep(2000);
            await lib.discord.guilds['@0.1.3'].members.roles.destroy({
              role_id: anotherUser.roles[i],
              user_id: event.mentions[0].id,
              guild_id: `${event.guild_id}`,
            });
          }
        }
      }
    }
  }
};
