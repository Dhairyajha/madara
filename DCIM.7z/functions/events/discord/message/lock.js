const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

let message = context.params.event.content;

let canUseAdminCommand = false;

let guildInfo = await lib.discord.guilds['@0.1.0'].retrieve({
  guild_id: `${context.params.event.guild_id}`,
});

let roles = await lib.discord.guilds['@0.1.0'].roles.list({
  guild_id: `${context.params.event.guild_id}`,
});

let userRoles = roles.filter((role) =>
  context.params.event.member.roles.includes(role.id)
);

for (let i = 0; i < userRoles.length; i++) {
  let _role = userRoles[i];
  if (_role.permission_names.includes('ADMINISTRATOR')) {
    canUseAdminCommand = true;
    break;
  }
}

if (guildInfo.owner_id === context.params.event.author.id) {
  canUseAdminCommand = true;
}
if (message.startsWith(`${commandPrefix}lock`)) {
  if (canUseAdminCommand) {
    await lib.discord.channels['@0.1.1'].permissions.update({
      overwrite_id: `${context.params.event.guild_id}`,
      channel_id: `${context.params.event.channel_id}`,
      deny: `${1 << 11}`,
      type: 0,
    });

    await lib.discord.channels['@0.1.1'].messages.create({
      channel_id: `${context.params.event.channel_id}`,
      content: `**🔒 | Channel is successfully Locked**`,
    });
  } else {
    if (!canUseAdminCommand) {
      await lib.discord.channels['@0.1.1'].messages.create({
        channel_id: `${context.params.event.channel_id}`,
        content: `Sorry, you need administrator level permissions to use this command.`,
      });
    }
  }
}
