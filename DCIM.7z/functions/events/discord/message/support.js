const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
  
  // Use this function to get the prefix in other files.
  // Use like `const prefix = await getGuildPrefix();`
  const getGuildPrefix = async () => {
    const prefixMap = await lib.utils.kv['@0.1.16'].get({
      key: 'prefix',
      defaultValue: {},
    });
    return prefixMap[context.params.event.guild_id] || '!';
  };
  
  const commandPrefix = await getGuildPrefix();
  
  if (context.params.event.content.startsWith(`${commandPrefix}support`)) {
  await lib.discord.channels['@0.2.0'].messages.create({
  "channel_id": `${context.params.event.channel_id}`,
  "content": "",
  "tts": false,
  "components": [
    {
      "type": 1,
      "components": [
        {
          "style": 5,
          "label": `server link`,
          "url": `https://discord.gg/Stn69HqHGv`,
          "disabled": false,
          "type": 2
        }
      ]
    }
  ],
  "embeds": [
    {
      "type": "rich",
      "title": `suport server`,
      "description": `click to join the server server `,
      "color": 0xff9500,
      "url": `https://discord.gg/Stn69HqHGv`
      }],
  });
  };