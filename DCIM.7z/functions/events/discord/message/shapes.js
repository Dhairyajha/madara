const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

let randomNumber = Math.floor(Math.random() * 8) + 1;
let shapes;
if (randomNumber === 1) {
  shapes = [`||🟦||`, `||🟧||`];
} else if (randomNumber === 2) {
  shapes = [`||🔵||`, `||🟠||`];
} else if (randomNumber === 3) {
  shapes = [`||🔷||`, `||🔶||`];
} else if (randomNumber === 4) {
  shapes = [`||🟪||`, `||🟥||`];
} else if (randomNumber === 5) {
  shapes = [`||🟣||`, `||🔴||`];
} else if (randomNumber === 5) {
  shapes = [`||🟦||`, `||🟪||`];
} else if (randomNumber === 6) {
  shapes = [`||🔵||`, `||🟣||`];
} else if (randomNumber === 7) {
  shapes = [`||🟨||`, `||🟩||`];
} else if (randomNumber === 8) {
  shapes = [`||🟡||`, `||🟢||`];
}
let getRandomChoice = () => {
  return shapes[Math.floor(Math.random() * shapes.length)];
};
let randomSelections1 = [...Array(5).keys()].map(getRandomChoice).join('');
let randomSelections2 = [...Array(5).keys()].map(getRandomChoice).join('');
let randomSelections3 = [...Array(5).keys()].map(getRandomChoice).join('');
let randomSelections4 = [...Array(5).keys()].map(getRandomChoice).join('');
let randomSelections5 = [...Array(5).keys()].map(getRandomChoice).join('');
let one = shapes[Math.floor(Math.random() * shapes.length)];
if (context.params.event.content.toLowerCase().startsWith(`${process.env.prefix}shapes`)) {
  await lib.discord.channels['@0.1.1'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: ``,
    tts: false,
    embed: {
      type: `rich`,
      title: `Shapes`,
      description: `${randomSelections1}
${randomSelections2}
${randomSelections3}
${randomSelections4}
${randomSelections5}`,
      color: 0x36373a,
    },
  });
}