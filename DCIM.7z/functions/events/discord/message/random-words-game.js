const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
var randomWords = require('random-words');
console.log(randomWords(5));
['army', 'beautiful', 'became', 'if', 'actually'];

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

if (context.params.event.content.trim() === `${commandPrefix}random`) {
  await lib.discord.channels['@0.0.6'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: ``,
    embed: {
      type: 'rich',
      title: `Make A sentence with:`,
      description: `${randomWords(3)}`, //change this number to the number of words, ${randomWords(5)}=5 words, ${randomWords(10)} = 10 words
      color: 0x2ef303,
    },
  });
}
