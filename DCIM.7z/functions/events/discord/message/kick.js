const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

if (context.params.event.content.startsWith(`${commandPrefix}kick`)) {
if (event.member.permission_names.includes('KICK'))
  await lib.discord.channels['@0.1.2'].messages.create({
    channel_id: event.channel_id, content,
  });

  if (guild.owner_id === context.params.event.author.id) {
    canKick = true;
  } else {
    let roles = await lib.discord.guilds['@0.1.0'].roles.list({
      guild_id: `${context.params.event.guild_id}`,
    });

    roles = roles.filter((role) => {
      return context.params.event.member.roles.indexOf(role.id) > -1;
    });

    for (let i = 0; i < roles.length; i++) {
      let role = roles[i];
      canKick =
        (role.permissions & (1 << 3)) === 1 << 3 ||
        (role.permissions & (1 << 1)) === 1 << 1;

      if (canKick) {
        break;
      }
    }
  }

  if (canKick) {
    try {
      let result = await lib.discord.guilds['@0.1.0'].members.destroy({
        user_id: `${mention.id}`,
        guild_id: `${context.params.event.guild_id}`,
      });

      let createdMessage = await lib.discord.channels['@0.1.0'].messages.create(
        {
          channel_id: `${context.params.event.channel_id}`,
          content: `Member Kicked`,
          message_reference: {
            message_id: context.params.event.id,
          },
        }
      );
    } catch (e) {
      console.log(e);
      await lib.discord.channels['@0.1.0'].messages.create({
        channel_id: `${context.params.event.channel_id}`,
        content: `failed to remove member`,
      });
    }
  } else {
    await lib.discord.channels['@0.1.0'].messages.create({
      channel_id: `${context.params.event.channel_id}`,
      content: `sorry you don't have permission`,
    });
  }
}
