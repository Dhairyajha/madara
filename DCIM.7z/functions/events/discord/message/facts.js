// authenticates you with the API standard library
const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
const somethingRandomOnDiscord = require('something-random-on-discord').Random

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

/* Trigger command */
if (context.params.event.content.startsWith(`${commandPrefix}fact`)) {
  /* Get some shocking facts */
  const { embed } = await somethingRandomOnDiscord.getFact()
  /* Set fav color */
  embed.color = 0xff0000
  /* Time to send it */
  return await lib.discord.channels['@0.1.1'].messages.create({
    channel_id: context.params.event.channel_id,
    content: ``,
    embed
  });
}

//CTK WARRIOR#7923 :3