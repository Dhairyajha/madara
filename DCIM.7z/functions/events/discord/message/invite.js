/**
 * An HTTP endpoint that acts as a webhook for Discord message.create event
 * @param {object} event
 * @returns {any} result
 */
module.exports = async (event, context) => {

  const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

  // Use this function to get the prefix in other files.
  // Use like `const prefix = await getGuildPrefix();`
  const getGuildPrefix = async () => {
    const prefixMap = await lib.utils.kv['@0.1.16'].get({
      key: 'prefix',
      defaultValue: {},
    });
    return prefixMap[context.params.event.guild_id] || '!';
  };
  const commandPrefix = await getGuildPrefix();
  if (event.content.startsWith(`${commandPrefix}inv`) || event.content.startsWith(`${commandPrefix}invite`)) {
      let info = await lib.discord.users['@0.1.5'].me.list();
      let id = info.id;
      let Avatar = info.avatar_url;
      await lib.discord.channels['@0.2.0'].messages.create({
        channel_id: `${context.params.event.channel_id}`,
        content: '',
        tts: false,
        embed: {
          type: 'rich',
          title: `Invite link`,
          description: `Click the button to invite me to your server!`,
          color: 0x0093ff,
          thumbnail: {
            url: Avatar,
          },
        },
        components: [
          {
            type: 1,
            components: [
              {
                style: 5,
                label: `Invite Link`,
                url: `https://discord.com/api/oauth2/authorize?client_id=894948538222518364&permissions=1103206009975&scope=bot`,
                disabled: false,
                type: 2,
              },
            ],
          },
        ],
      });
    }
  console.log(commandPrefix);


}