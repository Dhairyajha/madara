const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
const axios = require('axios');

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

if (context.params.event.content.startsWith(`${commandPrefix}happy`)) {
  const image = await axios('https://api.waifu.pics/sfw/happy').then((res) =>
    res.data ? res.data.url : null
  );

  if (!image)
    return lib.discord.channels['@0.2.0'].messages.create({
      content: `Oops sorry , something is wrong`,
      channel_id: context.params.event.channel_id,
    });

  await lib.discord.channels['@0.2.0'].messages.create({
    content: ``,
    channel_id: context.params.event.channel_id,
    embed: {
      title: ``,
      description: `<@${context.params.event.author.id}> is happy :smile:`,
      image: {url: image},
      color: 0xffc0cb,
    },
  });
}
