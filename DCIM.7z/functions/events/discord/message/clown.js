// authenticates you with the API standard library
// type `await lib.` to display API autocomplete
const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
const ID = context.params.event.mentions.length
  ? context.params.event.mentions[0].id
  : context.params.event.author.id;
const target = context.params.event.mentions[0]
  ? context.params.event.mentions[0].avatar
  : context.params.event.author.avatar;
const avatarLink = `https://cdn.discordapp.com/avatars/${ID}/${target}.png`;
const Time = new Date().toISOString();

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

if (context.params.event.content.startsWith(`${commandPrefix}clown`)) {
  const msg = await lib.discord.channels['@0.2.2'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: '',
    tts: false,
    embeds: [
      {
        type: 'rich',
        title: `Clown of the month 🤡`,
        description: `<@${context.params.event.mentions[0].id}> is a clown!`,
        color: 0xffffff,
        timestamp: `${Time}`,
        image: {
          url: `https://api.popcat.xyz/clown?image=${avatarLink}`,
          height: 0,
          width: 0,
        },
      },
    ],
  });
  await lib.discord.channels['@0.2.2'].messages.reactions.create({
    emoji: `🤡`,
    message_id: `${msg.id}`,
    channel_id: `${msg.channel_id}`,
  });
}
