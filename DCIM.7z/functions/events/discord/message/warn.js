module.exports = async (event, context) => {
const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

if (context.params.event.content.startsWith(`${commandPrefix}warn`)) {
let guildInfo = await lib.discord.guilds['@0.1.0'].retrieve({
            guild_id: `${context.params.event.guild_id}`
          });
          
          let roles = await lib.discord.guilds['@0.1.0'].roles.list({
            guild_id: `${context.params.event.guild_id}`
          });
          
          let userRoles = roles.filter((role) => context.params.event.member.roles.includes(role.id)); 
          
          for (let i = 0; i < userRoles.length; i++) {
            let _role = userRoles[i];
             if (_role.permission_names.includes('MANAGE MESSAGES')) {
          canUseAdminCommands = true;
              break;
            }
          }
          
          if (guildInfo.owner_id === context.params.event.author.id) {
            canUseAdminCommands = true;
          } 
            
          if (canUseAdminCommands) {
          const user_id = event.mentions[0].id;
          const range = `A:D`;
          let text = event.content.split(' ');
          let reason = context.params.event.content.split(' ').slice(2).join(' ') || 'No reason provided.';
          const user = context.params.event.user
          if (text[1] === `<@!${event.author.id}>`) {
            return lib.discord.channels['@0.0.6'].messages.create({
              channel_id: event.channel_id,
              content: `You can't warn yourself`,
            });
          } else if (!text[1]) {
            await lib.discord.channels['@0.0.6'].messages.create({
              channel_id: event.channel_id,
              content: `Please mention someone!`,
            });
          }
  let createdMessage = await lib.discord.channels['@0.3.0'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: ` `,
    embed: {
      description: `<@${event.mentions[0].id}> was warned\n\nReason: ${reason}`,
      color: 0xf3f3f3,
    },
  });
} else {
  await lib.discord.channels['@0.0.6'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: `sorry you dont have permission`,
  });
}
}
}