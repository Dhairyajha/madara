const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
let search = context.params.event.content.split(' ').slice(1).join(' ');

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

if (context.params.event.content.startsWith(`${commandPrefix}search`)) {
  await lib.discord.channels['@0.1.1'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: '',
    tts: false,
    components: [
      {
        type: 1,
        components: [
          {
            style: 5,
            label: `google link`,
            url: `https://www.google.com/search?q=${search}&oq=${search}&aqs=chrome..69i57.1069j0j1&sourceid=chrome&ie=UTF-8`,
            disabled: false,
            type: 2,
          },
        ],
      },
    ],
    embed: {
      type: 'rich',
      title: `Here U Go <@${context.params.event.author.id}>, Ur Search Result Of <${search}>`,
      description: ``,
      color: 0x62ff00,
    },
  });
}
