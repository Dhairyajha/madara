const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

let message = context.params.event.content;
let mainf = context.params.event.content.split(' ').slice(1).join(' ');
if (message.startsWith(`${commandPrefix}bugrep`)) {
  await lib.discord.channels['@0.1.1'].messages.create({
  channel_id:`${process.env.Bugreportchannel}`,
  content: ``,
  embed: {
    type: 'rich',
    title: 'Sent a new bug report:',
    description: `${mainf}`, 

    color: 0x4078c0,
    author: {
      name: `${context.params.event.author.username}#${context.params.event.author.discriminator}`,
      icon_url: `https://cdn.discordapp.com/avatars/${context.params.event.author.id}/${context.params.event.author.avatar}.png`
    }
  }
});
  await lib.discord.channels['@0.3.0'].messages.destroy({
    message_id:  context.params.event.id,
    channel_id: context.params.event.channel_id
  })
  await lib.discord.users['@0.2.0'].dms.create({
    recipient_id: context.params.event.author.id, // required
    content: ``,
      embed: {
        type: 'rich',
        title: 'Your bug report was:',
        description: `${mainf}`, 
        fields: [{
          name: 'Note This',
          value: [
            `**Hi **<@${context.params.event.author.id}> **Thanks for reporting us the bug !** \n **Your bug report is succesfully sent in <#${process.env.Bugreportchannel}>**\n **If you don't find your suggestion in __<#${process.env.Bugreportchannel}>__ please try excuting command again** \n ***__Thank you and have a nice day !__***`,
          ].join('\n')
        }],
        color: 0x4078c0,
        author: {
          name: `${context.params.event.author.username}#${context.params.event.author.discriminator}`,
          icon_url: `https://cdn.discordapp.com/avatars/${context.params.event.author.id}/${context.params.event.author.avatar}.png`
        }
   }
});
}