const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

let message = context.params.event.content;

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({ key: 'prefix', defaultValue: {} });
  return prefixMap[context.params.event.guild_id] || '!'
}

const commandPrefix = await getGuildPrefix();
if (message.startsWith(`${commandPrefix}vote server crmwy`)) {
await lib.discord.channels['@0.2.0'].messages.create({
  "channel_id": `${context.params.event.channel_id}`,
  "content": "",
  "tts": false,
  "components": [
    {
      "type": 1,
      "components": [
        {
          "style": 5,
          "label": `vote the server`,
          "url": `https://top.gg/servers/893368301974085632/vote`,
          "disabled": false,
          "type": 2
        }
      ]
    }
  ],
  "embeds": [
    {
      "type": "rich",
      "title": `server Vote`,
      "description": `Click the button to vote the server!`,
      "color": 0x00FFFF
    }
  ]
});
}
