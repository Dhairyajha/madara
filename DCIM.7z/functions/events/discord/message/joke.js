const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({ key: 'prefix', defaultValue: {} });
  return prefixMap[context.params.event.guild_id] || '!'
}

const commandPrefix = await getGuildPrefix();
if (context.params.event.content.startsWith(`${commandPrefix}joke`)) {
  var oneLinerJoke = require(`one-liner-joke`);

  /*
The variable getRandomJoke will contain a random joke with a format:
{"body":"Artificial intelligence is no match for natural stupidity.","tags":["intelligence","stupid"]}
*/
  var getRandomJoke = oneLinerJoke.getRandomJoke();
  console.log(getRandomJoke);

  /*
One can add exclusion filter for the jokes tags
default is ['racist', 'dirty', 'sex']
*/
  var getRandomJoke = oneLinerJoke.getRandomJoke({
    exclude_tags: ['clean', 'cars', 'nature', 'animals', 'games'],
  });

var getRandomJoke = getRandomJoke.body

  await lib.discord.channels['@0.2.0'].messages.create({
    channel_id: context.params.event.channel_id,
    content: `${getRandomJoke}`,
  });

  console.log(getRandomJoke);
}
