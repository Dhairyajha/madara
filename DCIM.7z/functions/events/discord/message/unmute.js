module.exports = async (event, context) => {
  const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

  // Use this function to get the prefix in other files.
  // Use like `const prefix = await getGuildPrefix();`
  const getGuildPrefix = async () => {
    const prefixMap = await lib.utils.kv['@0.1.16'].get({
      key: 'prefix',
      defaultValue: {},
    });
    return prefixMap[context.params.event.guild_id] || '!';
  };

  const commandPrefix = await getGuildPrefix();

  let sleep = async (ms) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve();
      }, ms || 0);
    });
  };

  if (context.params.event.content.startsWith(`${commandPrefix}unmute`)) {
    let canUnmute = false;
    let guild = await lib.discord.guilds['@0.1.0'].retrieve({
      guild_id: `${context.params.event.guild_id}`,
    });
    let roles = await lib.discord.guilds['@0.1.0'].roles.list({
      guild_id: event.guild_id,
    });

    let mutedRole = roles.find((role) => {
      return role.name.toLowerCase().startsWith('muted');
    });

    let authorRoles = roles.filter((role) => {
      return event.member.roles.indexOf(role.id) > -1;
    });

    if (guild.owner_id === event.author.id) {
      canUnmute = true;
    } else {
      for (let i = 0; i < authorRoles.length; i++) {
        let role = authorRoles[i];
        canUnmute =
          role.name.toLowerCase().match(/\bmod/i) ||
          role.name.toLowerCase().match(/\badmin/i) ||
          role.permission_names.includes('ADMINISTRATOR');
        if (canUnmute) {
          break;
        }
      }
    }
    if (canUnmute) {
      await lib.discord.channels['@0.1.1'].messages.create({
        channel_id: event.channel_id,
        content: ``,
        embed: {
          title: ``,
          type: 'rich',
          color: 0xabccff,
          description: `${event.mentions[0].username} is unmuted `,
        },
      });
      await lib.discord.guilds['@0.1.0'].members.roles.destroy({
        role_id: mutedRole.id,
        user_id: event.mentions[0].id,
        guild_id: event.guild_id,
      });
      let findroles = await lib.utils.kv['@0.1.16'].get({
        key: `userId_${event.mentions[0].id}_${event.guild_id}`,
      });
      for (let i = 0; i < findroles.length; i++) {
      var a = findroles;
      console.log(a[0]);
      console.log(findroles[0]);
      await sleep(1000);
      await lib.discord.guilds['@0.2.1'].members.roles.update({
        role_id: findroles[i],
        user_id: `${event.mentions[0].id}`,
        guild_id: `${event.guild_id}`
      });
      }
    } else {
      await lib.discord.channels['@0.0.6'].messages.create({
        channel_id: event.channel_id,
        content: `You dont have permission`,
      });
    }
  }
};
