const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});
let sleep = async (ms) => {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
};

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

if (context.params.event.content.startsWith(`${commandPrefix}botinfo`)) {
  const count = await getCount();
  
//REQUIRED INFORMATION (pls replace each and every value to your wish)

  let botcreatedate = `May 10 2021`;//reqrequired
  
  let botdev = `BoruMari#8927`;//the person/group of dev(s) who created the bot.
  
  let invitelink = `https://discord.com/oauth2/authorize?client_id=894948538222518364&scope=identify%20bot%20applications.commands&permissions=2146958591`;//put link only eg: https://blahblahbalh
  
  let botpfp = `https://www.google.com/imgres?imgurl=https%3A%2F%2Fpreview.redd.it%2F1zy2ue4br6q61.jpg%3Fauto%3Dwebp%26s%3Db9d473e85f7d65336aad954231089702e03735b5&imgrefurl=https%3A%2F%2Fwww.reddit.com%2Fr%2FBoruto%2Fcomments%2Fmgiv5u%2Fjust_want_to_share_my_boruto_and_himawari_fanart%2F&tbnid=YcI67803pGkzcM&vet=12ahUKEwjg_qz3qcL0AhUAx4sBHVUoCLAQMygCegUIARC9AQ..i&docid=a_SMYoRO1lO0iM&w=768&h=1024&itg=1&q=boruto%20and%20himawari&ved=2ahUKEwjg_qz3qcL0AhUAx4sBHVUoCLAQMygCegUIARC9AQ`;//recommend to use ibb.co or imgimgur
  
//REQUIRED INFORMATION EENDS

  await lib.discord.channels['@0.2.0'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: '',
    tts: false,
    embeds: [
      {
        type: 'rich',
        title: `${process.env.BOTNAME} BOT`,
        description: `${process.env.BOTNAME}is a bot made by ${botdev} \n\n**No. of servers Borumaki is in**:\n${count} servers!\n\n**Borumaki Bot Invite link**\n[Invite](${invitelink})\n\n**${process.env.BOTNAME} was created on:**\n${botcreatedate}\n\n**the help cmd:**\n${commandPrefix}help`,
        color: 0xff0000,
        thumbnail: {
          url: `${botpfp}`,
          height: 0,
          width: 0,
        },
        footer: {
          text: `${process.env.BOTNAME} Bot`,
        },
      },
    ],
  });

  async function getCount(id = null) {
    await sleep(1000);
    let result = await lib.discord.guilds['@0.1.0'].list({
      limit: 100,
      after: id,
    });

    let count = result.length;
    if (result.length % 100 === 0) count += await getCount(result[99].id);
    return count;
  }
}

//Made by SRM GRAPHICS
//discordusername : Steve57#0005

