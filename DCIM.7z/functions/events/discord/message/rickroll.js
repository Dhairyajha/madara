// authenticates you with the API standard library
const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({
    key: 'prefix',
    defaultValue: {},
  });
  return prefixMap[context.params.event.guild_id] || '!';
};

const commandPrefix = await getGuildPrefix();

let fileRequest = await lib.http.request['@1.1.5']({
  method: 'GET',
  url: 'https://zacher.public.files.stdlib.com/_stdlib/provider/zacher/images/rickroll.gif',
});
let file = fileRequest.body;

if (context.params.event.content === `${commandPrefix}rickroll`) {
  await lib.discord.channels['@0.2.0'].messages.create({
    channel_id: `${context.params.event.channel_id}`,
    content: 'never gonna give you up :smirk:',
    tts: false,
    file: file,
    filename: 'rickroll.gif',
  });
}
