module.exports = async (event, context) => {

  const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

  // Use this function to get the prefix in other files.
  // Use like `const prefix = await getGuildPrefix();`
  const getGuildPrefix = async () => {
    const prefixMap = await lib.utils.kv['@0.1.16'].get({ key: 'prefix', defaultValue: {} });
    return prefixMap[context.params.event.guild_id] || '!'
  }

  const commandPrefix = await getGuildPrefix();
  
  if(event.content.startsWith(`${commandPrefix}poll-ping`)) {
    let text = context.params.event.content.split(' ');
    let pollPing = context.params.event.content.split(' ')[1];
    console.table(pollPing);
    await lib.utils.kv['@0.1.16'].set({
      key: `pollPing_${context.params.event.guild_id}`,
      value: { role_id: pollPing },
    });
    await lib.discord.channels['@0.2.2'].messages.create({
      channel_id: event.channel_id,
      content: `The mentioned role is now setup as poll ping!`
    });
  }
  const details = await lib.utils.kv['@0.1.16'].get({
    key: `pollPing_${context.params.event.guild_id}`
  }).then(res => res)
  
  if(!details?.role_id) return;
  
  if (event.content.startsWith(`${commandPrefix}poll`)) {
    let polltext = context.params.event.content.split(' ').slice(1).join(' ');

  let createdMessage = await lib.discord.channels['@0.2.2'].messages.create({
      channel_id: `${context.params.event.channel_id}`,
      content: details.role_id,
      embed: {
        'title': `📊 Poll`,
        'description': polltext,
        'color': 0x000000,
      footer: { text: `Created by : ${event.author.username}`},
      },
    });
    
    console.table(details.role_id);
    await lib.discord.channels['@0.2.2'].messages.reactions.create({
      emoji: `👍`,
      message_id: `${createdMessage.id}`,
      channel_id: event.channel_id,
    });
    await lib.discord.channels['@0.2.2'].messages.reactions.create({
      emoji: `👎`,
      message_id: `${createdMessage.id}`,
      channel_id: event.channel_id,
      });
    }
}