module.exports = async (event, context) => {
const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

// Use this function to get the prefix in other files.
// Use like `const prefix = await getGuildPrefix();`
const getGuildPrefix = async () => {
  const prefixMap = await lib.utils.kv['@0.1.16'].get({ key: 'prefix', defaultValue: {} });
  return prefixMap[context.params.event.guild_id] || '!'
}

const commandPrefix = await getGuildPrefix();
  if (context.params.event.content.startsWith(`${commandPrefix}member autorole`)) {
    let roleString = context.params.event.content.split(' ')[2];
    await lib.discord.channels['@0.2.2'].messages.create({
      channel_id: `${context.params.event.channel_id}`,
      content: `${roleString} is now Member role`,
      message_reference: {
        message_id: context.params.event.id,
      },
    });
    console.table(event);
    console.log(`Setting up member role to ${roleString}`);
    await lib.utils.kv['@0.1.16'].set({
      key: `role_${context.params.event.guild_id}`,
      value: { role_id: roleString },
    });
  }
};
