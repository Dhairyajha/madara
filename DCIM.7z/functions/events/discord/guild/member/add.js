module.exports = async (event, context) => {
  const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

  const details = await lib.utils.kv['@0.1.16'].get({
    key: `role_${context.params.event.guild_id}`
  }).then(res => res)
  
  if(!details?.role_id) return;

console.log(details.role_id);
console.log(event);
await lib.discord.guilds['@0.1.0'].members.roles.update({
    role_id: details.role_id,
    user_id: `${context.params.event.user.id}`,
    guild_id: `${context.params.event.guild_id}`,
  });
};
